# MovieCatalogue

A simple movie catalogue app with MVP architecture

![device-2019-08-29-114820](https://user-images.githubusercontent.com/48062932/63911001-09fa3680-ca53-11e9-8fc2-edb218466ed0.png)

![device-2019-08-29-114846](https://user-images.githubusercontent.com/48062932/63911002-0a92cd00-ca53-11e9-8cc8-e996c55b07a5.png)

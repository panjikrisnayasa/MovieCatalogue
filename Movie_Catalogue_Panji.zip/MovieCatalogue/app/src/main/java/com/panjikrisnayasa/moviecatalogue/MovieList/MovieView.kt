package com.panjikrisnayasa.moviecatalogue.MovieList

interface MovieView {
    fun showRecyclerView()
}